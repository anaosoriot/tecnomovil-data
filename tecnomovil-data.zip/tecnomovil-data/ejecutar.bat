@echo off
chcp 65001 >nul
if exist out rmdir /s /q out
mkdir out
dir /s /b src\*.java > sources.txt
javac -encoding UTF-8 -d out @sources.txt
del sources.txt
echo === PRUEBAS ===
java -cp out co.edu.iudigital.tecnomovil.PruebasFuncionales
echo === PROGRAMA PRINCIPAL ===
java -Xmx2g -cp out co.edu.iudigital.tecnomovil.Main
