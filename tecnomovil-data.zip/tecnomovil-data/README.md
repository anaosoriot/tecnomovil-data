# TecnoMovil Data - Procesamiento funcional de transporte urbano

Evidencia de aprendizaje EA2. Creación de repositorio (S20)
Institución Universitaria Digital de Antioquia (IU Digital) - Tecnología en Desarrollo de Software
Asignatura: Programación Orientada a Objetos II - Docente: Jorge Armando Julio
Autora: Ana María Osorio Tabarez

## Descripción

Módulo escrito en Java, sin frameworks externos, que procesa un conjunto grande de registros simulados del sistema de transporte urbano de TecnoValle usando programación funcional: funciones puras, lambdas, colecciones inmutables y pipelines de Streams.

Resuelve seis análisis:

- a) Afluencia por estación
- b) Horas pico y horas valle
- c) Rutas más utilizadas
- d) Patrones de viaje por usuario
- e) Tiempo promedio entre estaciones
- f) Detección de sobrecarga en rutas

## Requisitos

- JDK 21 o superior (`java -version` y `javac -version`).
- No se usan librerías ni frameworks externos.

## Cómo ejecutar

Linux o macOS:

```bash
./ejecutar.sh
```

Windows:

```bat
ejecutar.bat
```

Manualmente:

```bash
mkdir out
javac -encoding UTF-8 -d out $(find src -name "*.java")
java -cp out co.edu.iudigital.tecnomovil.PruebasFuncionales
java -Xmx2g -cp out co.edu.iudigital.tecnomovil.Main
```

El script ejecuta primero las pruebas (15 comprobaciones) y luego el programa principal, que genera 1.198.944 registros simulados (200.000 usuarios, semilla 2026) e imprime los resultados.

## Estructura

```
src/main/java/co/edu/iudigital/tecnomovil/
  Main.java                      Capa imperativa (imprime en consola)
  modelo/                        Records inmutables: Registro, Ruta, TramoViaje, EstadoRuta y enum Accion
  datos/                         Catalogo de rutas y GeneradorDatos (simulador determinista)
  funcional/                     Funciones (lambdas) y AnalizadorTransporte (núcleo funcional)
src/test/java/co/edu/iudigital/tecnomovil/
  PruebasFuncionales.java        Pruebas sin frameworks
docs/                            Informe en PDF (APA 7)
evidencias/                      Capturas de la ejecución
```

## Conceptos funcionales aplicados

- Funciones puras: `TramoViaje.entre`, `estadoDeRuta` y los predicados de `Funciones`.
- Inmutabilidad: records, `List.copyOf`, `Collections.unmodifiableMap`.
- Lambdas y composición: `Predicate.and`, `Function.andThen`.
- Funciones de orden superior: `contarPor`, `deRuta`, `detectarSobrecarga` (recibe la capacidad como función).
- Streams y paralelización: `stream()` o `parallelStream()` con resultados idénticos.
