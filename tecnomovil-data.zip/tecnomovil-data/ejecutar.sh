#!/usr/bin/env bash
# Compila y ejecuta las pruebas y el programa principal (requiere JDK 21 o superior).
set -e
rm -rf out
mkdir out
javac -encoding UTF-8 -d out $(find src -name "*.java")
echo "=== PRUEBAS ==="
java -cp out co.edu.iudigital.tecnomovil.PruebasFuncionales
echo "=== PROGRAMA PRINCIPAL ==="
java -Xmx2g -cp out co.edu.iudigital.tecnomovil.Main
